//
//  LoginResponse.swift
//  LoginProject
//
//  Created by Allen H on 2022/11/14.
//

import Foundation

struct LoginResponse: Codable {
    let success: Bool
}
