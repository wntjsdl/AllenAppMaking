//
//  ToDoData+CoreDataClass.swift
//  MyToDoApp
//
//  Created by Allen H on 2022/04/21.
//
//

import Foundation
import CoreData

@objc(ToDoData)
public class ToDoData: NSManagedObject {

}
